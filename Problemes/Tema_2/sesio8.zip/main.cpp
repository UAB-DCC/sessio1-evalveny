
#include "Punt.h"
#include <iostream>
using namespace std;

const int MAXPUNTS1 = 3;
const int MAXPUNTS2 = 5;

void centroide(Punt* pIni, Punt* pFi,Punt* pCentroid)
{
	
	
}

void inicialitza(Punt* pIni, Punt* pFi, float* pVx,float* pVy)
{
	
}

int main()
{
	Punt poligon1[MAXPUNTS1];
	float valors1X[MAXPUNTS1] = { 10, 15, 5};
	float valors1Y[MAXPUNTS1] = { 5, 10, 10};

	Punt poligon2[MAXPUNTS2];
	float valors2X[MAXPUNTS2] = { 0, 10, 10, 5, 0 };
	float valors2Y[MAXPUNTS2] = { 0, 0, 10, 15, 10 };

	Punt centroid1,centroid2;

	//crides a inicialitza

	//crides a centroide

	cout << "Centroid de Poligon1 es ( " << centroid1.getX() << "," << centroid1.getY() << ")" << endl;//Hauria de donar (10,8.33333)
	cout << "Centroid de Poligon2 es ( " << centroid2.getX() << "," << centroid2.getY() << ")" << endl;//Hauria de donar (5,7)

	return 0;
}